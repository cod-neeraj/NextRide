import { useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { MapPin, Navigation, Calculator } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { AppCard } from "@/components/ui/AppCard";
import { AppInput } from "@/components/ui/AppInput";
import { AppButton } from "@/components/ui/AppButton";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { MapPlaceholder } from "@/components/maps/MapPlaceholder";
// import { estimateFare, bookRide } from "@/services/api";
import { useRideStore } from "@/stores/rideStore";
import { formatINR, formatDate } from "@/lib/format";
import { DUMMY_RIDES, DUMMY_DRIVER, DUMMY_ACTIVE_RIDE } from "@/lib/dummyData";
import type { Ride } from "@/types";

export function RiderDashboard() {
  // const navigate = useNavigate();
  // const { activeRide, setActiveRide } = useRideStore();
  // const [pickup, setPickup] = useState("Sector 17, Chandigarh");
  // const [dropoff, setDropoff] = useState("Chandigarh Airport");
  // const [estimate, setEstimate] = useState<number | null>(null);
  // const [loadingEst, setLoadingEst] = useState(false);
  // const [loadingBook, setLoadingBook] = useState(false);
  // const recent = DUMMY_RIDES;

  // const handleEstimate = async () => {
  //   if (!pickup || !dropoff) {
  //     toast.error("Enter pickup and drop-off");
  //     return;
  //   }
  //   setLoadingEst(true);
  //   try {
  //     const res = await estimateFare({ pickup, dropoff });
  //     setEstimate(res.fare);
  //     toast.success(`Estimated fare: ${formatINR(res.fare)}`);
  //   } catch {
  //     // Demo fallback
  //     const fare = 247;
  //     setEstimate(fare);
  //     toast.success(`Estimated fare: ${formatINR(fare)}`);
  //   } finally {
  //     setLoadingEst(false);
  //   }
  // };

  // const handleBook = async () => {
  //   if (!pickup || !dropoff) {
  //     toast.error("Enter pickup and drop-off");
  //     return;
  //   }
  //   setLoadingBook(true);
  //   try {
  //     const ride = await bookRide({ pickup, dropoff });
  //     setActiveRide(ride);
  //     toast.success("Ride booked! Finding a driver…");
  //     navigate(`/ride/${ride.id}`);
  //   } catch {
  //     // Demo fallback
  //     const ride: Ride = { ...DUMMY_ACTIVE_RIDE, pickup, dropoff, fare: estimate ?? 247 };
  //     setActiveRide(ride);
  //     toast.success("Ride booked (demo)! Finding a driver…");
  //     navigate(`/ride/${ride.id}`);
  //   } finally {
  //     setLoadingBook(false);
  //   }
  // };

  // return (
  //   <div className="min-h-screen bg-background">
  //     <Navbar />
  //     <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
  //       <div className="mb-6">
  //         <h1 className="text-2xl font-bold text-foreground">Where are you going?</h1>
  //         <p className="text-sm text-muted-foreground">Book your next ride in seconds.</p>
  //       </div>

  //       <div className="grid gap-6 lg:grid-cols-5">
  //         {/* Booking panel */}
  //         <div className="space-y-6 lg:col-span-2">
  //           <AppCard>
  //             <h2 className="text-base font-semibold text-foreground">Book a ride</h2>
  //             <div className="mt-4 space-y-3">
  //               <AppInput
  //                 label="Pickup"
  //                 value={pickup}
  //                 onChange={(e) => setPickup(e.target.value)}
  //                 leftIcon={<MapPin className="h-4 w-4 text-success" />}
  //                 placeholder="Where from?"
  //               />
  //               <AppInput
  //                 label="Drop-off"
  //                 value={dropoff}
  //                 onChange={(e) => setDropoff(e.target.value)}
  //                 leftIcon={<Navigation className="h-4 w-4 text-accent" />}
  //                 placeholder="Where to?"
  //               />
  //             </div>
  //             {estimate !== null && (
  //               <div className="mt-4 flex items-center justify-between rounded-lg border border-accent/20 bg-accent/5 px-4 py-3">
  //                 <span className="text-sm text-muted-foreground">Estimated fare</span>
  //                 <span className="text-xl font-bold text-accent">{formatINR(estimate)}</span>
  //               </div>
  //             )}
  //             <div className="mt-4 grid grid-cols-2 gap-3">
  //               <AppButton variant="outline" loading={loadingEst} onClick={handleEstimate}>
  //                 <Calculator className="h-4 w-4" /> Estimate
  //               </AppButton>
  //               <AppButton variant="secondary" loading={loadingBook} onClick={handleBook}>
  //                 Book ride
  //               </AppButton>
  //             </div>
  //           </AppCard>

  //           {activeRide && (
  //             <AppCard>
  //               <div className="flex items-center justify-between">
  //                 <h3 className="text-base font-semibold text-foreground">Active ride</h3>
  //                 <StatusBadge status={activeRide.status} />
  //               </div>
  //               <div className="mt-4 space-y-2 text-sm">
  //                 <div className="flex justify-between">
  //                   <span className="text-muted-foreground">Driver</span>
  //                   <span className="font-medium text-foreground">{activeRide.driver?.name ?? DUMMY_DRIVER.name}</span>
  //                 </div>
  //                 <div className="flex justify-between">
  //                   <span className="text-muted-foreground">Vehicle</span>
  //                   <span className="font-medium text-foreground">
  //                     {activeRide.driver?.vehicle ?? DUMMY_DRIVER.vehicle} · {activeRide.driver?.plate ?? DUMMY_DRIVER.plate}
  //                   </span>
  //                 </div>
  //                 <div className="flex justify-between">
  //                   <span className="text-muted-foreground">ETA</span>
  //                   <span className="font-medium text-foreground">{activeRide.etaMinutes ?? 4} min</span>
  //                 </div>
  //               </div>
  //               <AppButton
  //                 variant="primary"
  //                 fullWidth
  //                 className="mt-4"
  //                 onClick={() => navigate(`/ride/${activeRide.id}`)}
  //               >
  //                 View ride details
  //               </AppButton>
  //             </AppCard>
  //           )}
  //         </div>

  //         {/* Map */}
  //         <div className="lg:col-span-3">
  //           <MapPlaceholder pickup={pickup} dropoff={dropoff} />
  //         </div>
  //       </div>

  //       {/* Recent rides */}
  //       <section className="mt-10">
  //         <h2 className="text-lg font-semibold text-foreground">Recent rides</h2>
  //         <div className="mt-4 grid gap-3 sm:grid-cols-2">
  //           {recent.map((r) => (
  //             <AppCard key={r.id} className="!p-4">
  //               <div className="flex items-center justify-between">
  //                 <span className="text-xs text-muted-foreground">{formatDate(r.createdAt)}</span>
  //                 <StatusBadge status={r.status} />
  //               </div>
  //               <p className="mt-2 text-sm font-medium text-foreground">
  //                 {r.pickup} → {r.dropoff}
  //               </p>
  //               <p className="mt-1 text-base font-bold text-foreground">{formatINR(r.fare)}</p>
  //             </AppCard>
  //           ))}
  //         </div>
  //       </section>
  //     </main>
  //   </div>
  // );
}
