import type { AxiosInstance, InternalAxiosRequestConfig } from "axios";
import { authStorage } from "@/lib/authStorage";
import { useAuthStore } from "@/stores/authStore";

let isBootstrapping = false;

export function setAuthBootstrapping(value: boolean) {
  isBootstrapping = value;
}

function attachToken(config: InternalAxiosRequestConfig) {
  const token = useAuthStore.getState().token ?? authStorage.getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}

export function setupAuthInterceptor(axiosInstance: AxiosInstance) {
  axiosInstance.interceptors.request.use(attachToken);

  axiosInstance.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error?.response?.status !== 401 || isBootstrapping) {
        return Promise.reject(error);
      }

      const isSessionCheck = error.config?.url?.includes("/users/me");
      if (isSessionCheck) {
        return Promise.reject(error);
      }

      useAuthStore.getState().logout();
      if (typeof window !== "undefined" && window.location.pathname !== "/login") {
        window.location.href = "/login";
      }
      return Promise.reject(error);
    },
  );
}
