const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

let isRefreshing = false;
let refreshPromise: Promise<string | null> | null = null;

async function refreshAccessToken(): Promise<string | null> {

  if (isRefreshing && refreshPromise) {
    return refreshPromise;
  }

  isRefreshing = true;
  refreshPromise = fetch(`${API_URL}/auth/refresh`, {
    method: "POST",
    credentials: "include", 
  })
    .then(async (res) => {
      if (!res.ok) throw new Error("Refresh failed");
      const data = await res.json();
      const newAccessToken = data.data.accessToken;
      sessionStorage.setItem("accessToken", newAccessToken);
      return newAccessToken;
    })
    .catch(() => {
      // refresh token also expired — force logout
      sessionStorage.removeItem("accessToken");
      localStorage.removeItem("user");
      window.location.href = "/login";
      return null;
    })
    .finally(() => {
      isRefreshing = false;
      refreshPromise = null;
    });

  return refreshPromise;
}

type ApiOptions = RequestInit & { skipAuth?: boolean };

export async function apiCall<T = any>(
  endpoint: string,
  options: ApiOptions = {}
): Promise<T> {
  const accessToken = sessionStorage.getItem("accessToken");

  const doFetch = async (token: string | null) => {
    return fetch(`${API_URL}${endpoint}`, {
      ...options,
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...options.headers,
      },
    });
  };

  let res = await doFetch(accessToken);

  // access token expired -> refresh once, then retry original call
  if (res.status === 401 && !options.skipAuth) {
    const newToken = await refreshAccessToken();
    if (!newToken) {
      throw new Error("Session expired. Please login again.");
    }
    res = await doFetch(newToken);
  }

  const json = await res.json();

  if (!res.ok) {
    throw new Error(json?.message || "Something went wrong");
  }

  return json;
}