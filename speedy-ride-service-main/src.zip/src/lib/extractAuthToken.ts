import type { ApiResponse, AuthResponse } from "@/services/authService";

export function extractAuthToken(response: ApiResponse<AuthResponse>): string | null {
  const data = response.data;
  return (
    response.accessToken ??
    response.token ??
    data?.accessToken ??
    data?.token ??
    data?.jwt ??
    null
  );
}
