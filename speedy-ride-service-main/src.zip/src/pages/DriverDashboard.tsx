import { useEffect, useState, useCallback } from "react";
import toast from "react-hot-toast";
import { TrendingUp, MapPin, Navigation, Check, Play, Flag } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { AppCard } from "@/components/ui/AppCard";
import { AppButton } from "@/components/ui/AppButton";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Switch } from "@/components/ui/switch";
import { api } from "@/services/axiosClient";
import { formatINR, formatDate } from "@/lib/format";
import type { Ride, RideStatus } from "@/types";

export function DriverDashboard() {
  const [available, setAvailable] = useState(false);
  const [incoming, setIncoming] = useState<Ride | null>(null);
  const [activeRide, setActiveRide] = useState<Ride | null>(null);
  const [recentRides, setRecentRides] = useState<Ride[]>([]);
  const [loadingAction, setLoadingAction] = useState<string | null>(null);
  const [loadingDashboard, setLoadingDashboard] = useState(true);

  // ---- Initial dashboard load ----
  const fetchDashboard = useCallback(async () => {
    try {
      const { data } = await api.get("/api/driver/dashboard");
      // adjust these keys to match your actual response shape
      setAvailable(data.data.available);
      setIncoming(data.data.incomingRide ?? null);
      setActiveRide(data.data.activeRide ?? null);
      setRecentRides(data.data.recentRides ?? []);
    } catch (err) {
      toast.error("Failed to load dashboard");
    } finally {
      setLoadingDashboard(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboard();
  }, [fetchDashboard]);

  // ---- Poll for incoming ride requests while available and idle ----
  useEffect(() => {
    if (!available || activeRide) return;
    const interval = setInterval(async () => {
      try {
        const { data } = await api.get("/api/driver/incoming-ride");
        if (data.data) setIncoming(data.data);
      } catch {
        /* silent — just skip this poll cycle */
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [available, activeRide]);

  const toggleAvailability = async (val: boolean) => {
    const prev = available;
    setAvailable(val); // optimistic
    try {
      await api.post("/api/driver/availability", { available: val });
      toast.success(val ? "You're now available for rides" : "You're now offline");
      if (!val) setIncoming(null);
    } catch {
      setAvailable(prev); // rollback on failure
      toast.error("Couldn't update availability");
    }
  };

  const accept = async () => {
    if (!incoming) return;
    setLoadingAction("accept");
    try {
      await api.patch(`/api/rides/${incoming.id}`, { status: "DRIVER_ASSIGNED" });
      setActiveRide({ ...incoming, status: "DRIVER_ASSIGNED" });
      setIncoming(null);
      toast.success("Ride accepted!");
    } catch {
      toast.error("Failed to accept ride");
    } finally {
      setLoadingAction(null);
    }
  };

  const reject = async () => {
    if (!incoming) return;
    try {
      await api.patch(`/api/rides/${incoming.id}`, { status: "REJECTED" });
    } catch {
      /* non-blocking */
    }
    setIncoming(null);
    toast("Ride rejected");
  };

  const advance = async (next: RideStatus, label: string) => {
    if (!activeRide) return;
    setLoadingAction(next);
    try {
      await api.patch(`/api/rides/${activeRide.id}`, { status: next });
      if (next === "COMPLETED") {
        toast.success(`Ride completed! ${formatINR(activeRide.fare)} earned.`);
        setRecentRides((prev) => [{ ...activeRide, status: next }, ...prev]);
        setActiveRide(null);
      } else {
        setActiveRide({ ...activeRide, status: next });
        toast.success(label);
      }
    } catch {
      toast.error("Failed to update ride status");
    } finally {
      setLoadingAction(null);
    }
  };

  const todayRides = recentRides.filter((r) => r.status === "COMPLETED");
  const todayEarnings = todayRides.reduce((s, r) => s + r.fare, 0);

  if (loadingDashboard) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
          <p className="text-sm text-muted-foreground">Loading dashboard…</p>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Driver dashboard</h1>
            <p className="text-sm text-muted-foreground">Manage your rides and earnings.</p>
          </div>
          <AppCard className="!p-3 flex items-center gap-3">
            <StatusBadge status={available ? "AVAILABLE" : "OFFLINE"} />
            <Switch checked={available} onCheckedChange={toggleAvailability} />
          </AppCard>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            {available && incoming && !activeRide && (
              <AppCard className="border-accent/40 ring-2 ring-accent/10">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-semibold text-foreground">New ride request</h3>
                  <span className="rounded-full bg-warning/10 px-2 py-0.5 text-xs font-semibold text-warning">
                    Action needed
                  </span>
                </div>
                <div className="mt-4 space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <MapPin className="mt-0.5 h-4 w-4 text-success" />
                    <span className="font-medium text-foreground">{incoming.pickup}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Navigation className="mt-0.5 h-4 w-4 text-accent" />
                    <span className="font-medium text-foreground">{incoming.dropoff}</span>
                  </div>
                  <div className="flex items-center justify-between border-t border-border pt-3">
                    <span className="text-muted-foreground">Estimated fare</span>
                    <span className="text-lg font-bold text-foreground">{formatINR(incoming.fare)}</span>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <AppButton variant="danger" onClick={reject}>Reject</AppButton>
                  <AppButton variant="success" loading={loadingAction === "accept"} onClick={accept}>Accept</AppButton>
                </div>
              </AppCard>
            )}

            {activeRide && (
              <AppCard>
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-semibold text-foreground">Active ride</h3>
                  <StatusBadge status={activeRide.status} />
                </div>
                <div className="mt-4 space-y-2 text-sm">
                  <div className="flex items-start gap-2"><MapPin className="mt-0.5 h-4 w-4 text-success" /><span className="font-medium">{activeRide.pickup}</span></div>
                  <div className="flex items-start gap-2"><Navigation className="mt-0.5 h-4 w-4 text-accent" /><span className="font-medium">{activeRide.dropoff}</span></div>
                  <div className="flex items-center justify-between border-t border-border pt-3">
                    <span className="text-muted-foreground">Fare</span>
                    <span className="text-lg font-bold">{formatINR(activeRide.fare)}</span>
                  </div>
                </div>
                <div className="mt-4 grid gap-2 sm:grid-cols-3">
                  <AppButton
                    variant="outline"
                    disabled={activeRide.status !== "DRIVER_ASSIGNED"}
                    loading={loadingAction === "DRIVER_ARRIVED"}
                    onClick={() => advance("DRIVER_ARRIVED", "Marked as arrived")}
                  >
                    <Check className="h-4 w-4" /> Arrived
                  </AppButton>
                  <AppButton
                    variant="secondary"
                    disabled={activeRide.status !== "DRIVER_ARRIVED"}
                    loading={loadingAction === "IN_PROGRESS"}
                    onClick={() => advance("IN_PROGRESS", "Ride started")}
                  >
                    <Play className="h-4 w-4" /> Start
                  </AppButton>
                  <AppButton
                    variant="success"
                    disabled={activeRide.status !== "IN_PROGRESS"}
                    loading={loadingAction === "COMPLETED"}
                    onClick={() => advance("COMPLETED", "Ride completed")}
                  >
                    <Flag className="h-4 w-4" /> Complete
                  </AppButton>
                </div>
              </AppCard>
            )}

            {!incoming && !activeRide && available && (
              <AppCard className="text-center">
                <p className="text-sm text-muted-foreground">Waiting for ride requests…</p>
              </AppCard>
            )}

            {!available && (
              <AppCard className="text-center">
                <p className="text-sm text-muted-foreground">You're offline. Toggle availability to receive ride requests.</p>
              </AppCard>
            )}
          </div>

          <div className="space-y-6">
            <AppCard className="bg-primary text-primary-foreground border-primary">
              <div className="flex items-center gap-2 text-xs uppercase tracking-wide opacity-80">
                <TrendingUp className="h-4 w-4" /> Today's earnings
              </div>
              <p className="mt-3 text-4xl font-extrabold">{formatINR(todayEarnings)}</p>
              <p className="mt-1 text-sm opacity-80">{todayRides.length} completed rides</p>
            </AppCard>

            <AppCard>
              <h3 className="text-base font-semibold text-foreground">Recent rides</h3>
              <ul className="mt-3 divide-y divide-border">
                {recentRides.map((r) => (
                  <li key={r.id} className="flex items-center justify-between py-3">
                    <div>
                      <p className="text-sm font-medium text-foreground">{r.pickup} → {r.dropoff}</p>
                      <p className="text-xs text-muted-foreground">{formatDate(r.createdAt)}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-foreground">{formatINR(r.fare)}</p>
                      <StatusBadge status={r.status} className="mt-1" />
                    </div>
                  </li>
                ))}
              </ul>
            </AppCard>
          </div>
        </div>
      </main>
    </div>
  );
}