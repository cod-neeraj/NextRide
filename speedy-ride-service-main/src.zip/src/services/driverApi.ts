import axios from "axios";
import { setupAuthInterceptor } from "@/lib/setupAuthInterceptor";

const baseURL = import.meta.env.VITE_API_DRIVER_URL;

export const api = axios.create({
  baseURL,
  withCredentials: true,
  headers: {
    "Content-Type": "application/json",
  },
});

setupAuthInterceptor(api);
