// VehicleDetails.tsx
// Step 2: vehicle info + registration/insurance documents.

import React, { useState } from "react";
import type { DocumentSlot, VehicleDetailsForm } from "../../types/driver";
import { FileUploader } from "./FileUploader";

const VEHICLE_DOC_SLOTS: DocumentSlot[] = [
    {
        key: "rc_book",
        label: "Registration certificate (RC)",
        hint: "JPG, PNG or PDF, up to 5MB",
        required: true,
        accept: "image/*,.pdf",
        maxSizeMb: 5,
    },
    {
        key: "insurance",
        label: "Insurance certificate",
        hint: "Must be currently valid — JPG, PNG or PDF",
        required: true,
        accept: "image/*,.pdf",
        maxSizeMb: 5,
    },
    {
        key: "pollution_cert",
        label: "Pollution (PUC) certificate",
        hint: "JPG, PNG or PDF, up to 5MB",
        required: false,
        accept: "image/*,.pdf",
        maxSizeMb: 5,
    },
];

const inputClass =
    "w-full rounded-xl border border-[#2A2F3A] bg-[#12151C] px-3.5 py-2.5 text-[14px] text-[#F2F3F5] placeholder:text-[#5A6072] outline-none transition-colors focus:border-[#F2A93B]";
const labelClass = "mb-1.5 block text-[12px] font-semibold text-[#8B93A5]";

const VEHICLE_TYPES: { value: VehicleDetailsForm["vehicleType"]; label: string }[] = [
    { value: "two_wheeler", label: "Two-wheeler" },
    { value: "three_wheeler", label: "Three-wheeler" },
    { value: "four_wheeler", label: "Four-wheeler" },
];

export interface VehicleDetailsProps {
    onBack?: () => void;
    onContinue?: (form: VehicleDetailsForm, docs: DocumentSlot[]) => void;
    onUploadFile?: (file: File, slotKey: string) => Promise<void>;
}

export const VehicleDetails: React.FC<VehicleDetailsProps> = ({
    onBack,
    onContinue,
    onUploadFile,
}) => {
    const [form, setForm] = useState<VehicleDetailsForm>({
        vehicleType: "",
        make: "",
        model: "",
        year: "",
        registrationNumber: "",
        color: "",
    });
    const [docs, setDocs] = useState<DocumentSlot[]>(VEHICLE_DOC_SLOTS);

    const set = <K extends keyof VehicleDetailsForm>(key: K, value: VehicleDetailsForm[K]) =>
        setForm((f) => ({ ...f, [key]: value }));

    const formValid =
        form.vehicleType !== "" &&
        form.make.trim() !== "" &&
        form.model.trim() !== "" &&
        /^\d{4}$/.test(form.year) &&
        form.registrationNumber.trim() !== "";

    const docsValid = docs
        .filter((d) => d.required)
        .every((d) => d.file?.status === "verified");

    const canContinue = formValid && docsValid;

    return (
        <section className="mx-auto w-full max-w-3xl">
            {/* Header */}
            <header className="mb-8">
                <div className="flex items-center justify-between">
                    <span className='font-["IBM_Plex_Mono",monospace] text-xs font-semibold uppercase tracking-[0.18em] text-[#F2A93B]'>
                        Step 2 of 3
                    </span>

                    <span className="text-xs font-medium text-[#8B93A5]">
                        Vehicle Information
                    </span>
                </div>

                <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-[#2A2F3A]">
                    <div className="h-full w-2/3 rounded-full bg-[#F2A93B]" />
                </div>

                <h2 className='mt-6 font-["Space_Grotesk",sans-serif] text-3xl font-bold text-[#F2F3F5]'>
                    Vehicle Details
                </h2>

                <p className="mt-2 max-w-xl text-sm leading-6 text-[#8B93A5]">
                    Enter your vehicle information exactly as it appears on your
                    Registration Certificate (RC). This helps us verify your vehicle
                    quickly.
                </p>
            </header>

            {/* Vehicle Details */}
            <div className="rounded-2xl border border-[#2A2F3A] bg-[#1A1E27] p-6">
                <div className="mb-6">
                    <label className={labelClass}>Vehicle Type</label>

                    <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-3">
                        {VEHICLE_TYPES.map((t) => (
                            <button
                                key={t.value}
                                type="button"
                                onClick={() => set("vehicleType", t.value)}
                                className={[
                                    "rounded-xl border px-4 py-3 text-sm font-semibold transition-all duration-200",
                                    form.vehicleType === t.value
                                        ? "border-[#F2A93B] bg-[#F2A93B]/10 text-[#F2A93B]"
                                        : "border-[#2A2F3A] text-[#8B93A5] hover:border-[#3A404E] hover:bg-[#20252F]",
                                ].join(" ")}
                            >
                                {t.label}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                    <div>
                        <label className={labelClass}>Vehicle Make</label>
                        <input
                            className={inputClass}
                            placeholder="Honda"
                            value={form.make}
                            onChange={(e) => set("make", e.target.value)}
                        />
                    </div>

                    <div>
                        <label className={labelClass}>Vehicle Model</label>
                        <input
                            className={inputClass}
                            placeholder="Activa 6G"
                            value={form.model}
                            onChange={(e) => set("model", e.target.value)}
                        />
                    </div>

                    <div>
                        <label className={labelClass}>Manufacturing Year</label>
                        <input
                            className={inputClass}
                            placeholder="2023"
                            inputMode="numeric"
                            maxLength={4}
                            value={form.year}
                            onChange={(e) =>
                                set("year", e.target.value.replace(/\D/g, ""))
                            }
                        />
                    </div>

                    <div>
                        <label className={labelClass}>Vehicle Color</label>
                        <input
                            className={inputClass}
                            placeholder="White"
                            value={form.color}
                            onChange={(e) => set("color", e.target.value)}
                        />
                    </div>

                    <div className="md:col-span-2">
                        <label className={labelClass}>Registration Number</label>

                        <input
                            className={`${inputClass} font-["IBM_Plex_Mono",monospace] uppercase tracking-widest`}
                            placeholder="HR51AB1234"
                            value={form.registrationNumber}
                            onChange={(e) =>
                                set(
                                    "registrationNumber",
                                    e.target.value.toUpperCase()
                                )
                            }
                        />
                    </div>
                </div>
            </div>

            {/* Documents */}
            <div className="mt-8">
                <FileUploader
                    title="Vehicle Documents"
                    subtitle="Upload your Registration Certificate (RC) and active insurance document."
                    slots={docs}
                    onFilesChange={setDocs}
                    onUploadFile={onUploadFile}
                />
            </div>

            {/* Footer */}
            <div className="mt-10 border-t border-[#2A2F3A] pt-6">
                <div className="flex flex-col-reverse gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <button
                        type="button"
                        onClick={onBack}
                        className="flex h-12 items-center justify-center rounded-xl border border-[#2A2F3A] px-6 text-sm font-semibold text-[#B7BFCC] transition-all hover:border-[#3A404E] hover:bg-[#20252F] hover:text-white"
                    >
                        ← Back
                    </button>

                    <button
                        type="button"
                        disabled={!canContinue}
                        onClick={() => onContinue?.(form, docs)}
                        className={[
                            "flex h-12 min-w-[230px] items-center justify-center rounded-xl px-8 text-sm font-bold transition-all duration-200",
                            canContinue
                                ? "bg-[#F2A93B] text-[#12151C] shadow-lg shadow-[#F2A93B]/20 hover:-translate-y-0.5 hover:brightness-110"
                                : "cursor-not-allowed bg-[#2A2F3A] text-[#8B93A5]",
                        ].join(" ")}
                    >
                        Continue to Bank Details →
                    </button>
                </div>
            </div>
        </section>
    );
};

export default VehicleDetails;