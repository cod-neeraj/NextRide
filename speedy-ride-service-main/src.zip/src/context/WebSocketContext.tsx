import { createContext, useContext, useEffect, useRef, useCallback, useState } from "react";
import { Client } from "@stomp/stompjs";
import SockJS from "sockjs-client";
import { useAuthStore } from "@/stores/authStore";

const WS_URL = "http://localhost:2022/ws";

interface LocationPayload {
  lat: number;
  lng: number;
}

interface WebSocketContextValue {
  sendLocation: (payload: LocationPayload) => void;
  subscribe: (destination: string, callback: (msg: any) => void) => () => void;
  isConnected: boolean;
}

const WebSocketContext = createContext<WebSocketContextValue | null>(null);

export function WebSocketProvider({ children }: { children: React.ReactNode }) {
  const user = useAuthStore((s) => s.user);
  const clientRef = useRef<Client | null>(null);
  const connectedRef = useRef(false);
  const [isConnected, setIsConnected] = useState(false);

  // store pending subscriptions so we can re-subscribe on reconnect
  const subscriptionsRef = useRef<Map<string, (msg: any) => void>>(new Map());

  useEffect(() => {
    if (!user?.id) return;

    const client = new Client({
      webSocketFactory: () => new SockJS(WS_URL),
      connectHeaders: {
        userId: user.id,
        userType: user.role ?? "DRIVER", // use actual role from your auth store
      },
      reconnectDelay: 5000,

      onConnect: () => {
        console.log("WS connected:", user.id);
        connectedRef.current = true;
        setIsConnected(true);

        // re-subscribe everything after reconnect
        subscriptionsRef.current.forEach((callback, destination) => {
          client.subscribe(destination, (msg) => callback(JSON.parse(msg.body)));
        });
      },

      onDisconnect: () => {
        console.log("WS disconnected:", user.id);
        connectedRef.current = false;
        setIsConnected(false);
      },

      onStompError: (frame) => {
        console.error("STOMP error", frame);
        connectedRef.current = false;
        setIsConnected(false);
      },
    });

    client.activate();
    clientRef.current = client;

    return () => {
      connectedRef.current = false;
      client.deactivate();
      clientRef.current = null;
    };
  }, [user?.id]);

  const subscribe = useCallback((destination: string, callback: (msg: any) => void) => {
    // store it so reconnect can re-subscribe
    subscriptionsRef.current.set(destination, callback);

    // if already connected, subscribe immediately
    if (clientRef.current && connectedRef.current) {
      clientRef.current.subscribe(destination, (msg) => callback(JSON.parse(msg.body)));
    }

    // return unsubscribe function
    return () => {
      subscriptionsRef.current.delete(destination);
    };
  }, []);

  const sendLocation = useCallback(({ lat, lng }: LocationPayload) => {
    if (!clientRef.current || !connectedRef.current) {
      console.warn("sendLocation skipped — WS not connected");
      return;
    }
    clientRef.current.publish({
      destination: "/app/driver.location",
      body: JSON.stringify({
        driverId: user?.id,
        lat,
        lng,
        timestamp: Date.now(),
      }),
    });
  }, [user?.id]);

  return (
    <WebSocketContext.Provider value={{ sendLocation, subscribe, isConnected }}>
      {children}
    </WebSocketContext.Provider>
  );
}

export function useWebSocket() {
  const ctx = useContext(WebSocketContext);
  if (!ctx) throw new Error("useWebSocket must be used inside WebSocketProvider");
  return ctx;
}