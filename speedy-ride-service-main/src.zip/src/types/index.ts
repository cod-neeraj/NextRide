export type Role = "RIDER" | "DRIVER";

export type RideStatus =
  | "REQUESTED"
  | "DRIVER_ASSIGNED"
  | "DRIVER_ARRIVED"
  | "IN_PROGRESS"
  | "COMPLETED"
  | "CANCELLED";

export interface User {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  role: string;
}

export interface Driver {
  id: string;
  name: string;
  phone: string;
  vehicle: string;
  plate: string;
  rating: number;
}

export interface Ride {
  id: string;
  pickup: string;
  dropoff: string;
  fare: number;
  status: RideStatus;
  etaMinutes?: number;
  driver?: Driver;
  createdAt: string;
}
