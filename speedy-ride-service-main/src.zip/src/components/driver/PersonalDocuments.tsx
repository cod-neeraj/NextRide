// PersonalDocuments.tsx
// Step 1: identity & license documents. Thin wrapper around FileUploader
// with the specific document set for a driver's personal verification.

import React, { useState } from "react";
import type { DocumentSlot } from "../../types/driver";
import { FileUploader } from "./FileUploader";

const PERSONAL_DOC_SLOTS: DocumentSlot[] = [
    {
        key: "profile_photo",
        label: "Profile photo",
        hint: "A clear, recent selfie — JPG or PNG, up to 5MB",
        required: true,
        accept: "image/*",
        maxSizeMb: 5,
    },
    {
        key: "id_proof",
        label: "Government ID",
        hint: "Aadhaar, PAN or passport — JPG, PNG or PDF, up to 5MB",
        required: true,
        accept: "image/*,.pdf",
        maxSizeMb: 5,
    },
    {
        key: "license_front",
        label: "Driving license (front)",
        hint: "JPG, PNG or PDF, up to 5MB",
        required: true,
        accept: "image/*,.pdf",
        maxSizeMb: 5,
    },
    {
        key: "license_back",
        label: "Driving license (back)",
        hint: "JPG, PNG or PDF, up to 5MB",
        required: true,
        accept: "image/*,.pdf",
        maxSizeMb: 5,
    },
    {
        key: "address_proof",
        label: "Address proof",
        hint: "Utility bill or bank statement, less than 3 months old",
        required: false,
        accept: "image/*,.pdf",
        maxSizeMb: 5,
    },
];

export interface PersonalDocumentsProps {
    onContinue?: (slots: DocumentSlot[]) => void;
    /** Same contract as FileUploader.onUploadFile — hook up your API here. */
    onUploadFile?: (file: File, slotKey: string) => Promise<void>;
}

export const PersonalDocuments: React.FC<PersonalDocumentsProps> = ({
    onContinue,
    onUploadFile,
}) => {
    const [slots, setSlots] = useState<DocumentSlot[]>(PERSONAL_DOC_SLOTS);

    const requiredDone = slots
        .filter((s) => s.required)
        .every((s) => s.file?.status === "verified");

    return (
        <section className="mx-auto w-full max-w-2xl">
            <header className="mb-8">
                <div className="flex items-center justify-between">
                    <span className='font-["IBM_Plex_Mono",monospace] text-xs font-semibold uppercase tracking-[0.18em] text-[#F2A93B]'>
                        Step 1 of 3
                    </span>

                    <span className="text-xs font-medium text-[#8B93A5]">
                        Personal Verification
                    </span>
                </div>

                <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-[#2A2F3A]">
                    <div className="h-full w-1/3 rounded-full bg-[#F2A93B]" />
                </div>

                <h2 className='mt-6 font-["Space_Grotesk",sans-serif] text-3xl font-bold text-[#F2F3F5]'>
                    Verify Your Identity
                </h2>

                <p className="mt-2 max-w-xl text-sm leading-6 text-[#8B93A5]">
                    Upload clear photos of your identity documents. These documents are used
                    only for driver verification and are securely encrypted.
                </p>

                <div className="mt-5 rounded-xl border border-[#2A2F3A] bg-[#1A1E27] px-4 py-3">
                    <div className="flex items-start gap-3">
                        <span className="text-lg">📄</span>

                        <div>
                            <p className="text-sm font-semibold text-[#F2F3F5]">
                                Upload Guidelines
                            </p>

                            <ul className="mt-2 space-y-1 text-xs leading-5 text-[#8B93A5]">
                                <li>• Capture the entire document.</li>
                                <li>• Ensure all text is clearly readable.</li>
                                <li>• Avoid blurry, cropped, or dark images.</li>
                                <li>• JPG, PNG and PDF files up to 5 MB are supported.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
        </section>
    );
};

export default PersonalDocuments;